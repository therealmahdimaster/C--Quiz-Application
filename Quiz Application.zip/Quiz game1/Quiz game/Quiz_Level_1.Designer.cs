﻿
namespace Quiz_game
{
    partial class Quiz_Level_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.catergoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.questionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.option1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.option2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.option3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.option4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correctanswerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.newquestionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.questionDataSet = new Quiz_game.QuestionDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.wildlifeToolStrip = new System.Windows.Forms.ToolStrip();
            this.wildlifeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.newquestionTableAdapter = new Quiz_game.QuestionDataSetTableAdapters.newquestionTableAdapter();
            this.birdToolStrip = new System.Windows.Forms.ToolStrip();
            this.birdToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fishToolStrip = new System.Windows.Forms.ToolStrip();
            this.fishToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.newquestionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet)).BeginInit();
            this.wildlifeToolStrip.SuspendLayout();
            this.birdToolStrip.SuspendLayout();
            this.fishToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.catergoryDataGridViewTextBoxColumn,
            this.questionDataGridViewTextBoxColumn,
            this.option1DataGridViewTextBoxColumn,
            this.option2DataGridViewTextBoxColumn,
            this.option3DataGridViewTextBoxColumn,
            this.option4DataGridViewTextBoxColumn,
            this.correctanswerDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.newquestionBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 96);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(754, 150);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // catergoryDataGridViewTextBoxColumn
            // 
            this.catergoryDataGridViewTextBoxColumn.DataPropertyName = "Catergory";
            this.catergoryDataGridViewTextBoxColumn.HeaderText = "Catergory";
            this.catergoryDataGridViewTextBoxColumn.Name = "catergoryDataGridViewTextBoxColumn";
            this.catergoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // questionDataGridViewTextBoxColumn
            // 
            this.questionDataGridViewTextBoxColumn.DataPropertyName = "question";
            this.questionDataGridViewTextBoxColumn.HeaderText = "question";
            this.questionDataGridViewTextBoxColumn.Name = "questionDataGridViewTextBoxColumn";
            this.questionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // option1DataGridViewTextBoxColumn
            // 
            this.option1DataGridViewTextBoxColumn.DataPropertyName = "option1";
            this.option1DataGridViewTextBoxColumn.HeaderText = "option1";
            this.option1DataGridViewTextBoxColumn.Name = "option1DataGridViewTextBoxColumn";
            this.option1DataGridViewTextBoxColumn.ReadOnly = true;
            this.option1DataGridViewTextBoxColumn.Visible = false;
            // 
            // option2DataGridViewTextBoxColumn
            // 
            this.option2DataGridViewTextBoxColumn.DataPropertyName = "option2";
            this.option2DataGridViewTextBoxColumn.HeaderText = "option2";
            this.option2DataGridViewTextBoxColumn.Name = "option2DataGridViewTextBoxColumn";
            this.option2DataGridViewTextBoxColumn.ReadOnly = true;
            this.option2DataGridViewTextBoxColumn.Visible = false;
            // 
            // option3DataGridViewTextBoxColumn
            // 
            this.option3DataGridViewTextBoxColumn.DataPropertyName = "option3";
            this.option3DataGridViewTextBoxColumn.HeaderText = "option3";
            this.option3DataGridViewTextBoxColumn.Name = "option3DataGridViewTextBoxColumn";
            this.option3DataGridViewTextBoxColumn.ReadOnly = true;
            this.option3DataGridViewTextBoxColumn.Visible = false;
            // 
            // option4DataGridViewTextBoxColumn
            // 
            this.option4DataGridViewTextBoxColumn.DataPropertyName = "option4";
            this.option4DataGridViewTextBoxColumn.HeaderText = "option4";
            this.option4DataGridViewTextBoxColumn.Name = "option4DataGridViewTextBoxColumn";
            this.option4DataGridViewTextBoxColumn.ReadOnly = true;
            this.option4DataGridViewTextBoxColumn.Visible = false;
            // 
            // correctanswerDataGridViewTextBoxColumn
            // 
            this.correctanswerDataGridViewTextBoxColumn.DataPropertyName = "correctanswer";
            this.correctanswerDataGridViewTextBoxColumn.HeaderText = "correctanswer";
            this.correctanswerDataGridViewTextBoxColumn.Name = "correctanswerDataGridViewTextBoxColumn";
            this.correctanswerDataGridViewTextBoxColumn.ReadOnly = true;
            this.correctanswerDataGridViewTextBoxColumn.Visible = false;
            // 
            // newquestionBindingSource
            // 
            this.newquestionBindingSource.DataMember = "newquestion";
            this.newquestionBindingSource.DataSource = this.questionDataSet;
            // 
            // questionDataSet
            // 
            this.questionDataSet.DataSetName = "QuestionDataSet";
            this.questionDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(440, 384);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 4;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(88, 293);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            this.radioButton1.Click += new System.EventHandler(this.radioButton1_Click);
            this.radioButton1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton1_MouseClick);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(88, 384);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 6;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            this.radioButton2.Click += new System.EventHandler(this.radioButton2_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(392, 293);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 7;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            this.radioButton3.Click += new System.EventHandler(this.radioButton3_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(392, 384);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 8;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            this.radioButton4.Click += new System.EventHandler(this.radioButton4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(702, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Save Results";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // wildlifeToolStrip
            // 
            this.wildlifeToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wildlifeToolStripButton});
            this.wildlifeToolStrip.Location = new System.Drawing.Point(0, 0);
            this.wildlifeToolStrip.Name = "wildlifeToolStrip";
            this.wildlifeToolStrip.Size = new System.Drawing.Size(816, 25);
            this.wildlifeToolStrip.TabIndex = 10;
            this.wildlifeToolStrip.Text = "wildlifeToolStrip";
            // 
            // wildlifeToolStripButton
            // 
            this.wildlifeToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.wildlifeToolStripButton.Name = "wildlifeToolStripButton";
            this.wildlifeToolStripButton.Size = new System.Drawing.Size(51, 22);
            this.wildlifeToolStripButton.Text = "Wildlife";
            this.wildlifeToolStripButton.Click += new System.EventHandler(this.wildlifeToolStripButton_Click);
            // 
            // newquestionTableAdapter
            // 
            this.newquestionTableAdapter.ClearBeforeFill = true;
            // 
            // birdToolStrip
            // 
            this.birdToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.birdToolStripButton});
            this.birdToolStrip.Location = new System.Drawing.Point(0, 25);
            this.birdToolStrip.Name = "birdToolStrip";
            this.birdToolStrip.Size = new System.Drawing.Size(816, 25);
            this.birdToolStrip.TabIndex = 11;
            this.birdToolStrip.Text = "birdToolStrip";
            // 
            // birdToolStripButton
            // 
            this.birdToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.birdToolStripButton.Name = "birdToolStripButton";
            this.birdToolStripButton.Size = new System.Drawing.Size(32, 22);
            this.birdToolStripButton.Text = "Bird";
            this.birdToolStripButton.Click += new System.EventHandler(this.birdToolStripButton_Click);
            // 
            // fishToolStrip
            // 
            this.fishToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fishToolStripButton});
            this.fishToolStrip.Location = new System.Drawing.Point(0, 50);
            this.fishToolStrip.Name = "fishToolStrip";
            this.fishToolStrip.Size = new System.Drawing.Size(816, 25);
            this.fishToolStrip.TabIndex = 12;
            this.fishToolStrip.Text = "fishToolStrip";
            // 
            // fishToolStripButton
            // 
            this.fishToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fishToolStripButton.Name = "fishToolStripButton";
            this.fishToolStripButton.Size = new System.Drawing.Size(32, 22);
            this.fishToolStripButton.Text = "Fish";
            this.fishToolStripButton.Click += new System.EventHandler(this.fishToolStripButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(578, 415);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 13;
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // textBox2
            // 
            this.textBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox2.Location = new System.Drawing.Point(744, 70);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(60, 20);
            this.textBox2.TabIndex = 14;
            this.textBox2.Text = "00:00:00";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Quiz_Level_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 458);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.fishToolStrip);
            this.Controls.Add(this.birdToolStrip);
            this.Controls.Add(this.wildlifeToolStrip);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Quiz_Level_1";
            this.Text = "Quiz_Level_1";
            this.Load += new System.EventHandler(this.Quiz_Level_1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.newquestionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet)).EndInit();
            this.wildlifeToolStrip.ResumeLayout(false);
            this.wildlifeToolStrip.PerformLayout();
            this.birdToolStrip.ResumeLayout(false);
            this.birdToolStrip.PerformLayout();
            this.fishToolStrip.ResumeLayout(false);
            this.fishToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private QuestionDataSet questionDataSet;
        private System.Windows.Forms.BindingSource newquestionBindingSource;
        private QuestionDataSetTableAdapters.newquestionTableAdapter newquestionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn catergoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn questionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn option1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn option2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn option3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn option4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn correctanswerDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStrip wildlifeToolStrip;
        private System.Windows.Forms.ToolStripButton wildlifeToolStripButton;
        private System.Windows.Forms.ToolStrip birdToolStrip;
        private System.Windows.Forms.ToolStripButton birdToolStripButton;
        private System.Windows.Forms.ToolStrip fishToolStrip;
        private System.Windows.Forms.ToolStripButton fishToolStripButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}