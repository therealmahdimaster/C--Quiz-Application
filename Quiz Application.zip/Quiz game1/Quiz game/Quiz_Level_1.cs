﻿using System;
using System.Data.OleDb;
using System.Timers;
using System.Windows.Forms;

namespace Quiz_game
{

    public partial class Quiz_Level_1 : Form
    {
        System.Timers.Timer t;
        int h = 0, m = 10, s = 0, ms = 0;

        string correctans;
        int score = 0;
        public Quiz_Level_1()
        {
            InitializeComponent();
        }


        private static OleDbConnection GetConnection()
        {
            string connString;
            //  change to your connection string in the following line
            connString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=C:\Users\User\Desktop\Assigment\LEVEL 5\AWD\Quiz Game\Quiz Game\Question.mdb";
            return new OleDbConnection(connString);
        }



        private void Quiz_Level_1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'questionDataSet.newquestion' table. You can move, or remove it, as needed.
            this.newquestionTableAdapter.Fill(this.questionDataSet.newquestion);

            s = 1;
            t = new System.Timers.Timer();
            t.Interval = 10;
            t.Elapsed += OnTimeEvent;
            t.Start();
            
        }

        private void OnTimeEvent(object sender, ElapsedEventArgs e)
        {
            Invoke(new Action(() =>
            {
                ms -= 1;
                if (ms < 0)
                {
                    ms = 0;
                    s -= 1;
                }
                if (s < 0)
                {
                    s = 60;
                    m -= 1;
                }
                if (m < 0)
                {
                    m = 60;
                    h -= 1;
                }
                if (h < 0)
                {
                    h = 0;
                }
                if (ms == 0 && s == 0 && m == 0 && h == 0)
                {
                    t.Stop();
                    System.Windows.Forms.MessageBox.Show("Timer Ran out your score is " + score);
                    this.Close();

                    OleDbConnection myConnection = GetConnection();
                    string myQuery = "INSERT INTO score(score) VALUES('" + score + "')";
                    OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
                    try
                    {
                        {
                            //label5.Text = myQuery;
                            myConnection.Open();
                            myCommand.ExecuteNonQuery();
                            MessageBox.Show("Score Saved");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error connectiing" + ex);
                    }
                    finally
                    {
                        myConnection.Close();
                    }

                }
                textBox2.Text = string.Format("{0}:{1}:{2}:{3}", h.ToString().PadLeft(2, '0'), m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'), ms.ToString().PadLeft(2, '0'));
            }));
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                radioButton1.Text = row.Cells[3].Value.ToString();
                radioButton2.Text = row.Cells[4].Value.ToString();
                radioButton3.Text = row.Cells[5].Value.ToString();
                radioButton4.Text = row.Cells[6].Value.ToString();
                correctans = row.Cells[7].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show(score.ToString(), "Results");


            OleDbConnection myConnection = GetConnection();
            string myQuery = "INSERT INTO score(score) VALUES('" + score + "')";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            try
            {
                {
                    //label5.Text = myQuery;
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                    MessageBox.Show("Score Saved");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connectiing" + ex);
            }
            finally
            {
                myConnection.Close();
            }


            {
                this.Close();
            }










        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.FillBy(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.FillBy(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillByToolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.FillBy(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void wildlifeToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.Wildlife(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void catergoryToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.Catergory(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void birdsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.Birds(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void birdToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.Bird(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fishToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.Fish(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void testToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.newquestionTableAdapter.test(this.questionDataSet.newquestion);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_Click(object sender, EventArgs e)
        {


        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Text == correctans)
            {

                score = score + 1;


            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Text == correctans)
            {

                score = score + 1;


            }
        }

        private void radioButton3_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Text == correctans)
            {

                score = score + 1;


            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Text == correctans)
            {

                score = score + 1;


            }
        }



        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(correctans.ToString());
            //if (checkBox1.Text == correctans)
            //{
            //    MessageBox.Show(correctans.ToString());
            //    score = score + 1;




            //}
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(correctans.ToString());

        }



        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox1.Text == correctans)
            {

                score = score + 1;


            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            t.Start();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_MouseClick(object sender, MouseEventArgs e)
        {


        }

        private void checkBox1_CheckStateChanged_1(object sender, EventArgs e)
        {
        }
    }
}
