﻿using System.Windows.Forms;

namespace Quiz_game
{
    public partial class chart : Form
    {
        public chart()
        {
            InitializeComponent();
        }
    }
}
