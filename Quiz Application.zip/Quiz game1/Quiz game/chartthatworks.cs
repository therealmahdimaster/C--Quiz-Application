﻿using System;
using System.Windows.Forms;

namespace Quiz_game
{
    public partial class chartthatworks : Form
    {
        public chartthatworks()
        {
            InitializeComponent();
        }

        private void chartthatworks_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'questionDataSet9.Query1' table. You can move, or remove it, as needed.
            this.query1TableAdapter.Fill(this.questionDataSet9.Query1);


        }
    }
}
