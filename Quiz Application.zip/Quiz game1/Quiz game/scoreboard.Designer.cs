﻿
namespace Quiz_game
{
    partial class scoreboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.finalscoreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.questionDataSet1 = new Quiz_game.QuestionDataSet1();
            this.finalscoreTableAdapter = new Quiz_game.QuestionDataSet1TableAdapters.finalscoreTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.finalscoreBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.questionDataSet5 = new Quiz_game.QuestionDataSet5();
            this.questionDataSet4 = new Quiz_game.QuestionDataSet4();
            this.finalscoreBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.finalscoreTableAdapter1 = new Quiz_game.QuestionDataSet4TableAdapters.finalscoreTableAdapter();
            this.scoreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.finalscoreTableAdapter2 = new Quiz_game.QuestionDataSet5TableAdapters.finalscoreTableAdapter();
            this.questionDataSet6 = new Quiz_game.QuestionDataSet6();
            this.finalscoreBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.finalscoreTableAdapter3 = new Quiz_game.QuestionDataSet6TableAdapters.finalscoreTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // finalscoreBindingSource
            // 
            this.finalscoreBindingSource.DataMember = "finalscore";
            this.finalscoreBindingSource.DataSource = this.questionDataSet1;
            // 
            // questionDataSet1
            // 
            this.questionDataSet1.DataSetName = "QuestionDataSet1";
            this.questionDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // finalscoreTableAdapter
            // 
            this.finalscoreTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(708, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // finalscoreBindingSource2
            // 
            this.finalscoreBindingSource2.DataMember = "finalscore";
            this.finalscoreBindingSource2.DataSource = this.questionDataSet5;
            // 
            // questionDataSet5
            // 
            this.questionDataSet5.DataSetName = "QuestionDataSet5";
            this.questionDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // questionDataSet4
            // 
            this.questionDataSet4.DataSetName = "QuestionDataSet4";
            this.questionDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // finalscoreBindingSource1
            // 
            this.finalscoreBindingSource1.DataMember = "finalscore";
            this.finalscoreBindingSource1.DataSource = this.questionDataSet4;
            // 
            // finalscoreTableAdapter1
            // 
            this.finalscoreTableAdapter1.ClearBeforeFill = true;
            // 
            // scoreDataGridViewTextBoxColumn
            // 
            this.scoreDataGridViewTextBoxColumn.DataPropertyName = "score";
            this.scoreDataGridViewTextBoxColumn.HeaderText = "score";
            this.scoreDataGridViewTextBoxColumn.Name = "scoreDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.scoreDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.finalscoreBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(46, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(562, 172);
            this.dataGridView1.TabIndex = 0;
            // 
            // finalscoreTableAdapter2
            // 
            this.finalscoreTableAdapter2.ClearBeforeFill = true;
            // 
            // questionDataSet6
            // 
            this.questionDataSet6.DataSetName = "QuestionDataSet6";
            this.questionDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // finalscoreBindingSource3
            // 
            this.finalscoreBindingSource3.DataMember = "finalscore";
            this.finalscoreBindingSource3.DataSource = this.questionDataSet6;
            // 
            // finalscoreTableAdapter3
            // 
            this.finalscoreTableAdapter3.ClearBeforeFill = true;
            // 
            // scoreboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "scoreboard";
            this.Text = "scoreboard";
            this.Load += new System.EventHandler(this.scoreboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.questionDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalscoreBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private QuestionDataSet1 questionDataSet1;
        private System.Windows.Forms.BindingSource finalscoreBindingSource;
        private QuestionDataSet1TableAdapters.finalscoreTableAdapter finalscoreTableAdapter;
        private System.Windows.Forms.Button button1;
        private QuestionDataSet4 questionDataSet4;
        private System.Windows.Forms.BindingSource finalscoreBindingSource1;
        private QuestionDataSet4TableAdapters.finalscoreTableAdapter finalscoreTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn scoreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private QuestionDataSet5 questionDataSet5;
        private System.Windows.Forms.BindingSource finalscoreBindingSource2;
        private QuestionDataSet5TableAdapters.finalscoreTableAdapter finalscoreTableAdapter2;
        private QuestionDataSet6 questionDataSet6;
        private System.Windows.Forms.BindingSource finalscoreBindingSource3;
        private QuestionDataSet6TableAdapters.finalscoreTableAdapter finalscoreTableAdapter3;
    }
}