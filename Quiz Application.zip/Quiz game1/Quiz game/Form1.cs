﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ADOExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static OleDbConnection GetConnection()
        {
            string connString;
            //  change to your connection string in the following line
            connString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=C:\Users\User\Desktop\Assigment\LEVEL 5\AWD\Quiz Game\Quiz Game\Question.mdb";
            return new OleDbConnection(connString);
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {

        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }











        private void buttonSave_Click_2(object sender, EventArgs e)
        {
            OleDbConnection myConnection = GetConnection();
            string myQuery = "INSERT INTO newquestion(Catergory,question, option1, option2, option3, option4, correctanswer)  VALUES('" + comboBox1.SelectedItem + "' ,'" + Question.Text + "' , '" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox4.Text + "','" + answerbox.Text + "')";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            try
            {
                if (Question.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("Question is requierd");
                    return; // Validation to make sure that the question is entered 
                }


                if (answerbox.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("An answer  is requierd");
                    return; // Validation to make sure that the question is entered 
                }







                {
                    //label4.Text = myQuery;
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                    MessageBox.Show("Question Saved");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connectiing saving question" + ex);
            }
            finally
            {
                myConnection.Close();
            }




            {

                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "jpg files(.*jpg)|*.jpg| PNG files(.*png)|*.png| All Files(*.*)|*.*";



        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}