﻿using Quiz_game;
using System;
using System.Data.OleDb;
using System.Windows.Forms;


namespace ADOExample
{
    public partial class Startpage : Form
    //Example of Inheritance 
    {

        public Startpage()
        {
            InitializeComponent();


        }


        private static OleDbConnection GetConnection()
        {
            string connString;
            //  change to your connection string in the following line
            connString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=C:\Users\User\Desktop\Assigment\LEVEL 5\AWD\Quiz Game\Quiz Game\Question.mdb";
            return new OleDbConnection(connString);
        }






        private void label2_Click(object sender, EventArgs e)
        {

        }



        private void NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }



        private void Startpage_Load(object sender, EventArgs e)
        {

        }

        private void StartButton_Click_1(object sender, EventArgs e)
        {
            if (NameTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Name is requierd");
                return; // Validation to make sure that the name is entered 
            }


            {
                OleDbConnection myConnection = GetConnection();
                string myQuery = "INSERT INTO name(name)  VALUES('" + NameTextBox.Text + "')";
                OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
                try
                {
                    label4.Text = myQuery;
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connectiing" + ex);
                }
                finally
                {
                    myConnection.Close();
                }
            }


            Quiz_game.Quiz_Level_1 f2 = new Quiz_game.Quiz_Level_1();
            f2.ShowDialog(); // Shows Open the Quiz





        }

        private void QuitButton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ConstructorButton_Click(object sender, EventArgs e)
        {
            Form1 f2 = new Form1();
            f2.ShowDialog(); // Shows Open the Quiz
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ConstructorButton_Click_1(object sender, EventArgs e)
        {
            Form1 f2 = new Form1();
            f2.ShowDialog(); // Shows Open the Quiz
        }

        private void QuitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void StartButton_Click_2(object sender, EventArgs e)
        {


            if (NameTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Name is requierd");
                return; // Validation to make sure that the name is entered 
            }


            {
                OleDbConnection myConnection = GetConnection();
                string myQuery = "INSERT INTO name(name)  VALUES('" + NameTextBox.Text + "')";
                OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
                try
                {

                    myConnection.Open();
                    myCommand.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connectiing" + ex);
                }
                finally
                {
                    myConnection.Close();
                }
            }




            Quiz_Level_1 f2 = new Quiz_level_1();
            f2.ShowDialog(); // Shows Open the Quiz
        }

        private class Quiz_level_1 : Quiz_Level_1
        {
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void NameTextBox_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            chartthatworks f2 = new chartthatworks();
            f2.ShowDialog(); // Shows Open the Quiz
        }

        private void Startpage_Load_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
