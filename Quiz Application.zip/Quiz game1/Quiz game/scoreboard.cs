﻿using System;
using System.Windows.Forms;

namespace Quiz_game
{
    public partial class scoreboard : Form
    {
        public scoreboard()
        {
            InitializeComponent();
        }

        private void scoreboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'questionDataSet6.finalscore' table. You can move, or remove it, as needed.
            this.finalscoreTableAdapter3.Fill(this.questionDataSet6.finalscore);
            // TODO: This line of code loads data into the 'questionDataSet5.finalscore' table. You can move, or remove it, as needed.
            this.finalscoreTableAdapter2.Fill(this.questionDataSet5.finalscore);
            // TODO: This line of code loads data into the 'questionDataSet4.finalscore' table. You can move, or remove it, as needed.
            this.finalscoreTableAdapter1.Fill(this.questionDataSet4.finalscore);
            // TODO: This line of code loads data into the 'questionDataSet1.finalscore' table. You can move, or remove it, as needed.
            this.finalscoreTableAdapter.Fill(this.questionDataSet1.finalscore);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
